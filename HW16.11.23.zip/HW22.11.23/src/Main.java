import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

//        1 Дана длина в метрах. Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
//        Выведите начальное и конвертированные значения на экран.

        Random sc = new Random(0);
        int a = sc.nextInt(1000, 3000);
        System.out.println(a);
        System.out.println((a / 1000) + " км, " + (a / 1609.34) + " мили, " + (a / 0.3) + " футы, " + (a / 0.7112) + " аршины. ");
        System.out.println("-----------------------------");

//        2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
//        Выведите сумму сдачи в виде “X рублей и Y копеек”.

        Scanner s = new Scanner(System.in);
        System.out.println("Деньги пользователя");
        float klient = s.nextFloat();
        System.out.println("Стоймость покупки");
        float prodovec = s.nextFloat();
        float z = klient - prodovec;
        int x = (int) z;
        int y = (int) (10 * (z - x));
        System.out.println(x + " рублей и " + y + " копеек");
        System.out.println("-----------------------------");

//        3 Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут в поход.
//        Если тур кружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
//        В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи тренерского экзамена (isJimFree),
//        или тренер Кейт, если она вернётся из путешествия (hasKateComeBack). Вести детей может только один тренер.
//        Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
//        Напишите логическое выражение для вычисления того, состоится ли поход. Подберите условия, при которых поход состоится.
        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        System.out.println(isYearFinished&&(hasBoughtRaincoats||isGoodWeather)&&(isJimFree^hasKateComeBack));
        System.out.println("-----------------------------");

//        4 Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
//        Остаток деления можно отбросить. Операторы деления / и остатка от деления % применять нельзя.
        System.out.println("Введите число");
        byte q = s.nextByte();
        System.out.println(q>>1);



    }
}